package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Login extends RestAssuredBase{
	
	@Test
	public void login()//create login method 
	{
		//Step 1:Assigning Base Url to RestAssure baseURI
		
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api";
		
		//Step 2:getting response in Json format where login details passed in body.
		
		Response response = RestAssured.given().contentType(ContentType.JSON).body("{\r\n"
				+ "  \"username\": \"madhavi43\",\r\n"
				+ "  \"password\": \"Madhu@123\"\r\n"
				+ "}").post("users/login");
		
		//Step 3:Printing the response to validate
		response.prettyPrint();
		
		//Step 4 getting response in JSON format
		JsonPath path=response.jsonPath();
		
		//Step 5 getting id from the JsonPath
		 id = path.get("id");
		 
		 //Step 6 : printing the status code
		System.err.println(id);
		System.out.println(response.statusCode());
				
	}

}
