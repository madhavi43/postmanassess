package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Accountdetails extends RestAssuredBase{
	
	@Test(dependsOnMethods= {"uibank.Login.login"})
	public void accountdetails()
	{
		//Step 1:Assigning Base Url to RestAssure baseURI
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api";
		
		//Step 2:getting account details where condition used in queryPArams.
		Response response = RestAssured.given().header("authorization",id)
		.queryParams("filter[where][userId]","620f1dd78932d4005f2a8877")
		.get("accounts");
		
		//Step 3:Printing the response and status code.
		response.prettyPrint();
		System.err.println(response.statusCode());
		
	}
}


