package uibank;

public class RestAssuredBase {
	
	public static String id = "";

}
